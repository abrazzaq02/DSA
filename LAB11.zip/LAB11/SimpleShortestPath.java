/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package avl_tree;

/**
 *
 * @author Muhammad Qasim
 */
import java.util.*;

public class SimpleShortestPath {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of vertices: ");
        int vertices = scanner.nextInt();
        
        int[][] adjacencyMatrix = new int[vertices][vertices];

        System.out.print("Enter the number of edges: ");
        int edges = scanner.nextInt();
        System.out.println("Enter the edges (u, v) pairs:");
        for (int i = 0; i < edges; i++) {
            int u = scanner.nextInt() - 1; 
            int v = scanner.nextInt() - 1; 
            adjacencyMatrix[u][v] = 1;
            adjacencyMatrix[v][u] = 1; 
        }

        System.out.print("Enter the starting vertex: ");
        int start = scanner.nextInt() - 1; 
        System.out.print("Enter the destination vertex: ");
        int destination = scanner.nextInt() - 1; 

        
        findShortestPath(adjacencyMatrix, start, destination, vertices);
        scanner.close();
    }

    public static void findShortestPath(int[][] matrix, int start, int destination, int vertices) {
        boolean[] visited = new boolean[vertices]; 
        int[] parent = new int[vertices]; 
        Arrays.fill(parent, -1); 
        Queue<Integer> queue = new LinkedList<>();

        visited[start] = true; 
        queue.add(start);

        while (!queue.isEmpty()) {
            int current = queue.poll();

            
            if (current == destination) {
                printPath(parent, start, destination);
                return;
            }

            
            for (int i = 0; i < vertices; i++) {
                if (matrix[current][i] == 1 && !visited[i]) { 
                    visited[i] = true;
                    parent[i] = current; 
                    queue.add(i); 
                }
            }
        }
        System.out.println("No path found.");
    }

    public static void printPath(int[] parent, int start, int destination) {
        List<Integer> path = new ArrayList<>();
        for (int at = destination; at != -1; at = parent[at]) {
            path.add(at + 1);
        }
        Collections.reverse(path);
        System.out.print("Shortest Path: ");
        System.out.println(String.join(" → ", path.stream().map(String::valueOf).toArray(String[]::new)));
        System.out.println("Length: " + (path.size() - 1));
    }
}