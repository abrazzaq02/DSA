/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package avl_tree;

/**
 *
 * @author Muhammad Qasim
 */
import java.util.Scanner;

public class GraphWithReadableMatrix {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of vertices: ");
        int vertices = scanner.nextInt();
        int[][] adjacencyMatrix = new int[vertices][vertices];
        System.out.print("Enter the number of edges: ");
        int edges = scanner.nextInt();
        System.out.println("Enter the edges (u, v) pairs:");
        for (int i = 0; i < edges; i++) {
            int u = scanner.nextInt() - 1; // Convert to 0-based index
            int v = scanner.nextInt() - 1; // Convert to 0-based index
            adjacencyMatrix[u][v] = 1; // Mark the edge in the matrix
        }
        displayAdjacencyMatrix(adjacencyMatrix, vertices);

        scanner.close();
    }
    public static void displayAdjacencyMatrix(int[][] matrix, int vertices) {
        System.out.println("Adjacency Matrix:");
        System.out.print("   "); 
        for (int i = 1; i <= vertices; i++) {
            System.out.print(i + " "); 
        }
        System.out.println(); 

        
        for (int i = 0; i < vertices; i++) {
            System.out.print((i + 1) + " "); 
            for (int j = 0; j < vertices; j++) {
                System.out.print(matrix[i][j] + " "); 
            }
            System.out.println(); 
        }
    }
}