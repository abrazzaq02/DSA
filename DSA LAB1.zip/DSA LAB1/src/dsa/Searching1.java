/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dsa.lab1;

/**
 *
 * @author Muhammad Qasim
 */
public class Searching2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

      int array[]={11,22,33,44,55};
      int target=33;
     
      int left=0;
      int right=array.length-1;
      int middle; 
      boolean found=false;
      while(left<=right){
      middle=left+(right-left)/2;
      if(array[middle]==target){
     System.out.println("Elemen  "+target+" found at index : "+middle);
     found=true;
     break;
      }    
      if(array[middle]<target){
         left=middle+1;
        }
      else{
      right=middle-1;
      }
      }
      if(found==false){
          System.out.println("Element "+target+"not found:");
 }}}

    

