/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dsa.lab1;

/**
 *
 * @author Muhammad Qasim
 */
public class Searching {

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
    int array[]={13,26,39,52,65}; 
   int index=4;
   int element=array[index];
   System.out.println("Element At Index "+index+":"+element);    
    }
   

    }
    

