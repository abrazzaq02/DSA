/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package avl_tree;

/**
 *
 * @author Muhammad Qasim**/
 import java.util.*;

public class AllPathBtwTwoVertices {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter the number of vertices: ");
        int vertices = scanner.nextInt();
  
        List<List<Integer>> adjacencyList = new ArrayList<>();
        for (int i = 0; i < vertices; i++) {
            adjacencyList.add(new ArrayList<>());
        }

        
        System.out.print("Enter the number of edges: ");
        int edges = scanner.nextInt();
        System.out.println("Enter the edges (u, v) pairs:");
        for (int i = 0; i < edges; i++) {
            int u = scanner.nextInt() - 1;
            int v = scanner.nextInt() - 1;
            adjacencyList.get(u).add(v);
            adjacencyList.get(v).add(u); 
        }

        
        System.out.print("Enter the starting vertex: ");
        int start = scanner.nextInt() - 1;
        System.out.print("Enter the destination vertex: ");
        int destination = scanner.nextInt() - 1; 

       
        List<List<Integer>> allPaths = new ArrayList<>();
        boolean[] visited = new boolean[vertices]; 
        List<Integer> path = new ArrayList<>(); 
        findAllPaths(adjacencyList, start, destination, visited, path, allPaths);

        // Step 6: Print all paths
        System.out.println("Paths:");
        for (List<Integer> p : allPaths) {
            for (int i = 0; i < p.size(); i++) {
                System.out.print((p.get(i) + 1)); 
                if (i < p.size() - 1) {
                    System.out.print(" -> "); 
                }
            }
            System.out.println(" (Length: " + (p.size() - 1) + ")"); 
        }

        scanner.close();
    }

 
    public static void findAllPaths(List<List<Integer>> adjacencyList, int current, int destination, boolean[] visited, List<Integer> path, List<List<Integer>> allPaths) {
        visited[current] = true; 
        path.add(current); 

        if (current == destination) {
            allPaths.add(new ArrayList<>(path)); 
        } else {
           
            for (int neighbor : adjacencyList.get(current)) {
                if (!visited[neighbor]) { 
                    findAllPaths(adjacencyList, neighbor, destination, visited, path, allPaths);
                }
            }
        }

      
        visited[current] = false;
        path.remove(path.size() - 1);
    }
}
