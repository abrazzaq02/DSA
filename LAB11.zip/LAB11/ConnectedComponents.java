/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package avl_tree;

/**
 *
 * @author Muhammad Qasim
 */
import java.util.*;

public class ConnectedComponents {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of vertices: ");
        int vertices = scanner.nextInt();

       
        int[][] adjacencyMatrix = new int[vertices][vertices];
        System.out.println("Enter the adjacency matrix (0 for no edge, 1 for edge):");
        for (int i = 0; i < vertices; i++) {
            for (int j = 0; j < vertices; j++) {
                adjacencyMatrix[i][j] = scanner.nextInt();
            }
        }

       
        boolean[] visited = new boolean[vertices]; 
        List<List<Integer>> components = new ArrayList<>(); 

        for (int i = 0; i < vertices; i++) {
            if (!visited[i]) { // If the vertex is not visited
                List<Integer> component = new ArrayList<>(); 
                dfs(adjacencyMatrix, visited, i, component); 
                components.add(component); 
            }
        }

      
        System.out.println("Connected Components:");
        for (int i = 0; i < components.size(); i++) {
            System.out.print("Component " + (i + 1) + ": {");
            for (int j = 0; j < components.get(i).size(); j++) {
                System.out.print((components.get(i).get(j) + 1)); 
                if (j < components.get(i).size() - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println("}");
        }

        scanner.close();
    }

    
    public static void dfs(int[][] matrix, boolean[] visited, int current, List<Integer> component) {
        visited[current] = true; 
        component.add(current); 

     
        for (int i = 0; i < matrix.length; i++) {
            if (matrix[current][i] == 1 && !visited[i]) {
                dfs(matrix, visited, i, component); 
            }
        }
    }
}
